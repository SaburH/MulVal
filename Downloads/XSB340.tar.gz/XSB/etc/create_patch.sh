#!/bin/sh
cvs diff -u -b -B $@
