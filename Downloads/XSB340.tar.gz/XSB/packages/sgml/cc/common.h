#include "fetch_file.c"
#include "parser.c"
#include "charmap.c" 
#include "util.c"
#include "xmlns.c"
#include "model.c"
#include <assert.h>
